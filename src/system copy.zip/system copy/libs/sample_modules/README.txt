Sample declarations of .mjs (ESM - ECMAScript 6 modules).
Demonstrates exporting and importing simple snippets
that was defined as modules.