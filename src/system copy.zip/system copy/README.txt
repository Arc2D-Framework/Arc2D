System is made up of framework/infastructure.
    - Devices and drivers
    - Engines
    - Parsers
    - 3rd party libs/apis
    - Networking
    - Http
    - I/O Disk


Basically any technology bits that are low-level