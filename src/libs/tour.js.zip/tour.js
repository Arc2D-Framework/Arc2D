var HELP = {
    "items" : [
        {
            "title" : "Step A",
            "target" : "#btn-toggle-a",
            "text" : "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here",
            "items" : [
                {
                  "target":"#btn-toggle-b", 
                  "title" : "Step A.1",  
                  "text": "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text"
			    },
			    {
                  "target":"#btn-toggle-a", 
                  "title" : "Step A.2",  
                  "text": "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected"
			    }
            ]
        },
        {
            "title" : "Step B",
            "target" : "#btn-toggle-b",
            "text" : "Finalizes item"
        }
    ]
}

/*
class Paginator {
    constructor(options) {
        super();
        this.data = options.data;
        this.pageSize = options.pageSize;
        this.currentPage=("currentPage" in options)? options.currentPage:0;
    }

    next(){
        //next goes to next page set
        if(this.currentPage==this.totalpages()){this.currentPage--};
        var d = this.data.slice(this.currentPage*this.pageSize, (this.currentPage+1)*this.pageSize);
        this.currentPage++;
        // this.dispatchEvent("change", {type: "next", currentPage:this.currentPage});
        // this.dispatchEvent("next", {currentPage:this.currentPage});
        return d;
    }

    update(){
        var d = this.data.slice((this.currentPage-1)*this.pageSize, (this.currentPage)*this.pageSize);
        // this.dispatchEvent("change", {type: "next", currentPage:this.currentPage});
        return d;
    }

    previous(){
        if(this.currentPage<=1){this.currentPage=1;}
        else{this.currentPage--}
        var previousPage = this.currentPage;
        var d = this.data.slice((previousPage*this.pageSize)-this.pageSize, (previousPage)*this.pageSize);
        // this.dispatchEvent("change", {type: "previous", currentPage:this.currentPage});
        // this.dispatchEvent("previous", {currentPage:this.currentPage});
        return d;
    }

    current(){
        if(this.currentPage<=1){this.currentPage=1;}
        if(this.currentPage==this.totalpages()){this.currentPage--};
        var d = this.data.slice(this.currentPage*this.pageSize, (this.currentPage+1)*this.pageSize);
        return d;
    }

    pagenumber(){
        return this.currentPage;
    }

    totalpages(){
        return Math.ceil(this.data.length/this.pageSize);
    }

    totalrecords(){
        return this.data.length;//Math.ceil(this.data.length/this.pageSize);
    }

    islastpage(){
        return this.currentPage >= this.totalpages();
    }

    isfirstpage(){
        return this.currentPage <= 1;
    }

    resetindex(){
        this.currentPage = 0;
    }

    first(){
        this.resetindex();
        // this.dispatchEvent("change", {type: "first", currentPage:this.currentPage});
        return this.next();
    }

    last(){
        this.currentPage = this.totalpages();
        // this.dispatchEvent("change", {type: "last", currentPage:this.currentPage});
    }

    resizepage(size){
        this.pageSize = size || this.pageSize;
        this.resetindex();
        // this.dispatchEvent("change", {type: "resize", currentPage:this.currentPage});
    }

    pagesize(){
        return this.pageSize;
    }
};*/

class TourGuide extends HTMLElement {
    constructor() {
        super();
        this.root = this.attachShadow({ mode: "open" });
        let template = document.createElement("template");
        this.stepIndex = -1;
        template.innerHTML = `
            <style>
                :host {
                    visibility:hidden;
                }

                :host(.active) {
                    visibility:visible;
                }

                :host {
                    position: absolute;
                    background-color: white;
                    max-width: 320px;
                    min-width: 320px;
                    display: block;
                    font-size: .8rem;
                    z-index: 1000;
                    padding: 11px;
                    border: 1px solid gray;
                    border-radius: 4px;
                    box-shadow: 0px 0px 8px 0px rgb(0 0 0 / 50%);
                    z-index:110;
                  }

                 
                  :host:before {
                    border: 8px solid transparent;
                    content: "";
                    position: absolute;
                  }
                  
                  :host(.bottom):before {
                    top: -16px;
                    border-bottom-color: #fff;
                  }
                  :host(.right):before {
                    right: 16px;
                  }
                  
                  :host(.top):before {
                    bottom: -16px;
                    border-top-color: #fff;
                  }

                  :host(.left):before {
                    left: 20px;
                    border-top-color: #fff;
                  }

                  :host #help-tour-title {
                    color: black;
                    font-size: 20px;
                    display: flex;
                    flex-flow: row nowrap;
                    justify-content: space-between;
                    align-items: center;
                  }
                  :host #help-tour-title:after {
                    content: "\\274C";
                    display: inline-block;
                    float: right;
                    color: black;
                    font-size: 10px;
                    padding: 6px;
                    background: #80808017;
                  }
                  :host #help-tour-text {
                    max-height: 100px;
                    overflow-y: auto;
                    color: gray;
                  }
                  :host #help-tour-nav{
                    background: #80808021;
                    padding: 11px;
                    text-align: center;
                    border-radius: 3px;
                    display: flex;
                    flex-flow: row nowrap;
                    justify-content: space-between;
                    margin: 0 !important;
                  }
                  :host #help-tour-title,
                  :host #help-tour-text,
                  :host #help-tour-nav {
                      margin: 10px;
                      text-align: left;
                  }

                  :host #help-tour-nav button {
                    height: 40px;
                    min-width: 70px;
                    border: 1px solid #8080803b;
                    border-radius: 3px;
                  }

                  :host #help-tour-nav button.next {
                    background: #4ca76a;
                    color: white;
                  }      
                  
                  :host #help-tour-nav button.skip {
                    border: none;
                    background: none;
                    color: #dd0000;
                    text-decoration: underline;
                    cursor: pointer;
                  }
            </style>
            <h3 id="help-tour-title">Title Here</h3>
            <div id="help-tour-text">Description Here</div>
            <nav id="help-tour-nav">
                <button class="skip">Skip</button>
                <button class="next">Next</button>
            </nav>
        `;
        
        this.root.appendChild(template.content.cloneNode(true));
    }
    
    connectedCallback() {
        window.tg=this;
        this.titleEl = this.root.querySelector("h3");
        this.textEl = this.root.querySelector("#help-tour-text");
        this.btnNext = this.root.querySelector("button.next");
        this.btnNext.addEventListener("click", e=>this.onNext(e), false);

        this.btnPrevious = this.root.querySelector("button.skip");
        this.btnPrevious.addEventListener("click", e=>this.onPrevious(e), false);
        // window.addEventListener("load", e=> this.onload(e), false)
        this.iterator = this.getIterator(HELP.items);
        this.current = this.iterator.next().value;
    }

    show() {
        this.setOverlay();
        this.classList.add("active");
        if(!this.current) {
            this.iterator = this.getIterator(HELP.items);
            this.current = this.iterator.next().value;
        }
        this.next()
    }

    hide() {
        this.removeOverlay();
        this.classList.remove("active");
    }
    
    * getIterator (array) {
        for (var item of array) {
            yield item;
            if(item.items) {
                for(let subitem of item.items) {yield subitem}
            }
        }
    }

    next() {
        // debugger
        // var step = HELP.guides[this.stepIndex];
        // var step = this.iterator.next().value;
        var step = this.current;
        if(step) {
            this.setTarget(step.target);
            this.setTitle(step.title);
            this.setText(step.text);
            this.setPosition();
        }
        else {
            this.hide();
        }
        this.current = this.iterator.next().value;
        this.update();
    }


    update() {
        // debugger
        if(!this.current){
            this.btnNext.innerHTML = "Finish"
        }
        else {
            this.btnNext.innerHTML = "Next"
        }
    }

    onNext() {
        // this.stepIndex++;
        // if(this.stepIndex > HELP.guides.length) {
        //     this.stepIndex = HELP.guides.length
        // }
        this.next();
    }

    onPrevious() {
        // this.stepIndex--;
        // if(this.stepIndex < 0) {this.stepIndex=0}
        // this.next();
    }

    setPosition() {
        var target_coords = this.target.getBoundingClientRect();
        var label_coords = this.getBoundingClientRect();
        this.style.top = `${target_coords.top-label_coords.height}px`;
        this.style.left = `${target_coords.left}px`;
    }

    setTarget(cssSelector) {
        this.target = document.querySelector(cssSelector);
        this.target.style.zIndex = 101;
        this.target.style.position = this.target.style.position||"relative";
    }
    setTitle(str) {
        var title = str||this.target.getAttribute("data-tour-title");
        this.titleEl.innerHTML = title||"Title Here";
    }

    setText(str){
        var text = str||this.target.getAttribute("data-tour-text");
        this.textEl.innerHTML = text||"Title Here";
    }

    setOverlay() {
        this.overlay = this.overlay||document.createElement("div");
        this.overlay.id = "tour-guide-overlay";
        document.body.append(this.overlay)
    }

    removeOverlay() {
        if(this.overlay) {
            this.overlay.remove();
            this.overlay = null;
        }
    }

    onload(e){
        // setTimeout(e => {

        // }, 1000)
        
    }
}

customElements.define('tour-guide', TourGuide);