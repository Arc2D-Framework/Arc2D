<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="tree" tilewidth="110" tileheight="128" tilecount="1" columns="1" objectalignment="topleft">
 <editorsettings>
  <export target="tree.json" format="json"/>
 </editorsettings>
 <image source="tree.png" width="110" height="128"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="52.6364" y="103.409" width="29.9545" height="8.27273"/>
  </objectgroup>
 </tile>
</tileset>
