<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Barrels" tilewidth="68" tileheight="45" tilecount="1" columns="1">
 <editorsettings>
  <export target="Barrels.json" format="json"/>
 </editorsettings>
 <image source="../../images/barrel_68x45.png" width="68" height="45"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3.5" y="24.5" width="60" height="17"/>
  </objectgroup>
 </tile>
</tileset>
