<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="da" tilewidth="110" tileheight="128" tilecount="2" columns="0">
 <editorsettings>
  <export target="da.json" format="json"/>
 </editorsettings>
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="110" height="128" source="tree.png"/>
 </tile>
 <tile id="1">
  <image width="95" height="128" source="tree2.png"/>
 </tile>
</tileset>
