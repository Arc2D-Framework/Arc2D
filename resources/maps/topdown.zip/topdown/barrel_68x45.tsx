<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="barrel_68x45" tilewidth="68" tileheight="45" tilecount="1" columns="1" objectalignment="topleft">
 <editorsettings>
  <export target="barrel_68x45.json" format="json"/>
 </editorsettings>
 <image source="../../images/barrel_68x45.png" width="68" height="45"/>
 <tile id="0">
  <properties>
   <property name="barrel" value="yes"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="25" width="59.5" height="15.5"/>
  </objectgroup>
 </tile>
</tileset>
