<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="super_retro" tilewidth="16" tileheight="16" tilecount="304" columns="16">
 <editorsettings>
  <export target="super_retro.json" format="json"/>
 </editorsettings>
 <image source="atlas_16x.png" width="256" height="304"/>
 <tile id="177">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0869565" y="5.04348" width="15.8261" height="10.7826"/>
  </objectgroup>
 </tile>
</tileset>
