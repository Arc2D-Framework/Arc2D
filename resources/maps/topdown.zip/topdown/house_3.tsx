<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="house_3" tilewidth="240" tileheight="326" tilecount="1" columns="1" objectalignment="topleft">
 <editorsettings>
  <export target="house_3.json" format="json"/>
 </editorsettings>
 <image source="../../images/house_3.png" width="240" height="326"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="40.5" y="132.333" width="156.333" height="185.333"/>
  </objectgroup>
 </tile>
</tileset>
