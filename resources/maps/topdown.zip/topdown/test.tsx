<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="test" tilewidth="896" tileheight="896" tilecount="1" columns="0" objectalignment="topleft">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="896" height="896" source="../../../../../../Downloads/taur_walk.png"/>
 </tile>
</tileset>
