<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="stone_2" tilewidth="128" tileheight="128" tilecount="1" columns="1" objectalignment="topleft">
 <editorsettings>
  <export target="stone_2.json" format="json"/>
 </editorsettings>
 <grid orientation="orthogonal" width="34" height="34"/>
 <image source="../../images/stone_2.png" width="128" height="128"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="2" x="23" y="57" width="84" height="35"/>
  </objectgroup>
 </tile>
</tileset>
