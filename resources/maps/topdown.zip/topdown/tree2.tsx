<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="tree2" tilewidth="95" tileheight="128" tilecount="1" columns="1" objectalignment="topleft">
 <editorsettings>
  <export target="tree2.json" format="json"/>
 </editorsettings>
 <image source="tree2.png" width="95" height="128"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="29" y="104.5" width="26" height="10"/>
  </objectgroup>
 </tile>
</tileset>
