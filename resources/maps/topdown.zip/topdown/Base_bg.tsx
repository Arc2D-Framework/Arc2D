<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="Base_bg" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <editorsettings>
  <export target="Base_bg.json" format="json"/>
 </editorsettings>
 <image source="../../images/Base_bg.png" width="16" height="16"/>
</tileset>
