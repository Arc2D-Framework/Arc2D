<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="char_spritesheet" tilewidth="76" tileheight="140" tilecount="10" columns="10">
 <image source="../images/char_spritesheet.png" width="788" height="140"/>
</tileset>
