<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="character_sprite_sheet" tilewidth="76" tileheight="140" tilecount="9" columns="9">
 <image source="../images/character_sprite_sheet.png" width="720" height="140"/>
</tileset>
