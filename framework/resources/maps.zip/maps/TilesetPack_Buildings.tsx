<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="TilesetPack_Buildings" tilewidth="256" tileheight="256" tilecount="14" columns="7">
 <editorsettings>
  <export target="TilesetPack_Buildings.json" format="json"/>
 </editorsettings>
 <image source="../images/TilesetPack_Buildings.png" width="1792" height="512"/>
</tileset>
